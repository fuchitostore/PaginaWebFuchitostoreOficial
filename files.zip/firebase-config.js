// ══════════════════════════════════════════════════════════════
//  firebase-config.js  —  FuchitoStore
//  SDK v9 modular (compat layer para uso sin bundler)
//  ► Reemplaza los valores YOUR_* con los de tu proyecto Firebase
// ══════════════════════════════════════════════════════════════

// ── 1. SDK v9 (compat) desde CDN ──────────────────────────────
// Agrega estas 3 líneas en el <head> de index.html y account.html:
//
//   <script src="https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js"></script>
//   <script src="https://www.gstatic.com/firebasejs/10.12.0/firebase-auth-compat.js"></script>
//   <script src="https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore-compat.js"></script>
//
// Luego, ANTES de cerrar </body>, añade en orden:
//   <script src="firebase-config.js"></script>
//   <script src="auth.js"></script>
//   <script src="favorites.js"></script>   <!-- solo en index.html -->
//   <script src="rewards.js"></script>
//   <script src="account.js"></script>     <!-- solo en account.html -->

(function () {
  'use strict';

  // ── Credenciales del proyecto ──────────────────────────────
  // Cópialas desde: Consola Firebase → Configuración del proyecto → Tu aplicación web
  var firebaseConfig = {
    apiKey:            "YOUR_API_KEY",
    authDomain:        "YOUR_PROJECT_ID.firebaseapp.com",
    projectId:         "YOUR_PROJECT_ID",
    storageBucket:     "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId:             "YOUR_APP_ID"
  };

  // ── Inicialización (idempotente) ───────────────────────────
  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }

  // ── Instancias globales (accesibles desde auth.js, etc.) ──
  window.FS_AUTH = firebase.auth();
  window.FS_DB   = firebase.firestore();

  // ── Persistencia: sesión sobrevive al reload ───────────────
  window.FS_AUTH.setPersistence(firebase.auth.Auth.Persistence.LOCAL)
    .catch(function (err) { console.warn('[FuchitoStore] Auth persistence:', err.message); });

  console.log('[FuchitoStore] Firebase inicializado ✔');
})();
