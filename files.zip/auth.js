// ══════════════════════════════════════════════════════════════
//  auth.js  —  FuchitoStore
//  Login Google + Email/Password, modal de sesión, botón en nav
//  Depende de: firebase-config.js (debe cargarse antes)
// ══════════════════════════════════════════════════════════════

(function () {
  'use strict';

  // ── Inyectar estilos del modal ─────────────────────────────
  var style = document.createElement('style');
  style.textContent = [
    /* Overlay */
    '#fs-auth-overlay{',
      'display:none;position:fixed;inset:0;z-index:9000;',
      'background:rgba(9,9,15,0.88);backdrop-filter:blur(10px);',
      'align-items:center;justify-content:center',
    '}',
    '#fs-auth-overlay.fs-open{display:flex}',

    /* Modal */
    '#fs-auth-modal{',
      'background:var(--bg2);border:1px solid rgba(57,255,20,0.2);',
      'border-radius:16px;padding:40px 36px;width:100%;max-width:400px;',
      'box-shadow:0 0 60px rgba(57,255,20,0.08),0 24px 64px rgba(0,0,0,0.6);',
      'position:relative',
    '}',

    /* Cerrar */
    '#fs-auth-close{',
      'position:absolute;top:16px;right:16px;background:transparent;',
      'border:none;color:rgba(255,255,255,0.35);font-size:1.3rem;cursor:pointer;',
      'transition:color 0.2s;line-height:1',
    '}',
    '#fs-auth-close:hover{color:var(--white)}',

    /* Logo */
    '.fs-modal-logo{font-family:"Bebas Neue",sans-serif;font-size:1.6rem;',
      'letter-spacing:2px;color:var(--neon);text-align:center;margin-bottom:4px}',
    '.fs-modal-sub{font-size:0.75rem;color:rgba(255,255,255,0.4);',
      'text-align:center;margin-bottom:28px}',

    /* Tabs */
    '.fs-tabs{display:flex;gap:0;border-bottom:1px solid rgba(255,255,255,0.08);margin-bottom:24px}',
    '.fs-tab{flex:1;padding:10px;background:transparent;border:none;',
      'font-size:0.78rem;font-weight:600;color:rgba(255,255,255,0.35);',
      'cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px;',
      'transition:color 0.2s,border-color 0.2s}',
    '.fs-tab.active{color:var(--neon);border-bottom-color:var(--neon)}',

    /* Inputs */
    '.fs-input{width:100%;background:var(--bg3);border:1px solid rgba(255,255,255,0.08);',
      'border-radius:8px;padding:11px 14px;font-size:0.85rem;color:var(--white);',
      'outline:none;transition:border-color 0.2s;margin-bottom:12px;',
      'font-family:"Inter",sans-serif}',
    '.fs-input:focus{border-color:rgba(57,255,20,0.4)}',
    '.fs-input::placeholder{color:rgba(255,255,255,0.22)}',

    /* Botones */
    '.fs-btn-primary{width:100%;padding:12px;border-radius:8px;border:none;',
      'background:var(--neon);color:var(--bg);font-weight:700;font-size:0.85rem;',
      'cursor:pointer;transition:opacity 0.2s;margin-top:4px}',
    '.fs-btn-primary:hover{opacity:0.85}',
    '.fs-btn-primary:disabled{opacity:0.45;cursor:not-allowed}',

    '.fs-btn-google{width:100%;padding:11px;border-radius:8px;',
      'border:1px solid rgba(255,255,255,0.12);background:var(--bg3);',
      'color:var(--white);font-weight:600;font-size:0.82rem;cursor:pointer;',
      'display:flex;align-items:center;justify-content:center;gap:10px;',
      'transition:border-color 0.2s;margin-bottom:16px}',
    '.fs-btn-google:hover{border-color:rgba(255,255,255,0.28)}',

    /* Divider */
    '.fs-divider{display:flex;align-items:center;gap:10px;margin-bottom:16px}',
    '.fs-divider span{font-size:0.7rem;color:rgba(255,255,255,0.2)}',
    '.fs-divider::before,.fs-divider::after{content:"";flex:1;',
      'height:1px;background:rgba(255,255,255,0.07)}',

    /* Error */
    '.fs-error{font-size:0.75rem;color:#FF3B3B;text-align:center;',
      'margin-top:10px;min-height:18px}',

    /* Nav: botón usuario */
    '#fs-nav-btn{display:flex;align-items:center;gap:7px;background:transparent;',
      'border:1px solid rgba(57,255,20,0.3);color:var(--neon);',
      'font-weight:600;font-size:0.78rem;padding:9px 18px;border-radius:6px;',
      'cursor:pointer;transition:all 0.2s;white-space:nowrap}',
    '#fs-nav-btn:hover{background:rgba(57,255,20,0.08)}',

    /* Menú desplegable */
    '#fs-nav-menu{position:absolute;top:calc(100% + 8px);right:0;',
      'background:var(--bg2);border:1px solid rgba(57,255,20,0.15);',
      'border-radius:10px;padding:8px;min-width:180px;',
      'box-shadow:0 12px 40px rgba(0,0,0,0.5);',
      'display:none;flex-direction:column;gap:2px;z-index:600}',
    '#fs-nav-menu.open{display:flex}',
    '.fs-menu-item{display:flex;align-items:center;gap:9px;',
      'padding:10px 12px;border-radius:7px;font-size:0.8rem;',
      'color:rgba(255,255,255,0.7);text-decoration:none;',
      'background:transparent;border:none;cursor:pointer;',
      'transition:background 0.15s,color 0.15s;width:100%;text-align:left}',
    '.fs-menu-item:hover{background:rgba(255,255,255,0.05);color:var(--white)}',
    '.fs-menu-item.danger{color:rgba(255,80,80,0.8)}',
    '.fs-menu-item.danger:hover{color:#FF3B3B}',

    /* Badge nivel en nav */
    '#fs-nav-badge{font-size:0.6rem;font-weight:700;padding:2px 7px;',
      'border-radius:20px;background:rgba(57,255,20,0.1);',
      'color:var(--neon);border:1px solid rgba(57,255,20,0.2)}',
  ].join('');
  document.head.appendChild(style);

  // ── HTML: overlay + modal ──────────────────────────────────
  var overlayEl = document.createElement('div');
  overlayEl.id = 'fs-auth-overlay';
  overlayEl.innerHTML = [
    '<div id="fs-auth-modal">',
      '<button id="fs-auth-close" aria-label="Cerrar">✕</button>',
      '<div class="fs-modal-logo">⚽ FuchitoStore</div>',
      '<div class="fs-modal-sub">Tu cuenta, tus jerseys, tus recompensas</div>',

      '<div class="fs-tabs">',
        '<button class="fs-tab active" data-panel="login">Iniciar sesión</button>',
        '<button class="fs-tab" data-panel="register">Registrarse</button>',
      '</div>',

      /* Login */
      '<div id="fs-panel-login">',
        '<button class="fs-btn-google" id="fs-google-login">',
          '<svg width="18" height="18" viewBox="0 0 18 18"><path fill="#EA4335" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"/><path fill="#4285F4" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z"/><path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/><path fill="#34A853" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 6.29C4.672 4.163 6.656 3.58 9 3.58z"/></svg>',
          'Continuar con Google',
        '</button>',
        '<div class="fs-divider"><span>o</span></div>',
        '<input class="fs-input" id="fs-login-email" type="email" placeholder="Correo electrónico" autocomplete="email">',
        '<input class="fs-input" id="fs-login-pass"  type="password" placeholder="Contraseña" autocomplete="current-password">',
        '<button class="fs-btn-primary" id="fs-login-submit">Iniciar sesión</button>',
        '<div class="fs-error" id="fs-login-err"></div>',
      '</div>',

      /* Register */
      '<div id="fs-panel-register" style="display:none">',
        '<button class="fs-btn-google" id="fs-google-register">',
          '<svg width="18" height="18" viewBox="0 0 18 18"><path fill="#EA4335" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"/><path fill="#4285F4" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z"/><path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/><path fill="#34A853" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 6.29C4.672 4.163 6.656 3.58 9 3.58z"/></svg>',
          'Registrarse con Google',
        '</button>',
        '<div class="fs-divider"><span>o</span></div>',
        '<input class="fs-input" id="fs-reg-name"  type="text"     placeholder="Tu nombre" autocomplete="name">',
        '<input class="fs-input" id="fs-reg-email" type="email"    placeholder="Correo electrónico" autocomplete="email">',
        '<input class="fs-input" id="fs-reg-pass"  type="password" placeholder="Contraseña (mín. 6 caracteres)" autocomplete="new-password">',
        '<button class="fs-btn-primary" id="fs-reg-submit">Crear cuenta</button>',
        '<div class="fs-error" id="fs-reg-err"></div>',
      '</div>',
    '</div>',
  ].join('');
  document.body.appendChild(overlayEl);

  // ── Inyectar botón en nav ──────────────────────────────────
  var navRight = document.querySelector('.nav-wa') || document.querySelector('nav');
  var navWrapper = document.createElement('div');
  navWrapper.style.cssText = 'position:relative;display:inline-flex;align-items:center';
  navWrapper.innerHTML =
    '<button id="fs-nav-btn">👤 Mi cuenta</button>' +
    '<div id="fs-nav-menu">' +
      '<a href="account.html" class="fs-menu-item">🧾 Mi perfil</a>' +
      '<a href="account.html#favoritos" class="fs-menu-item">❤️ Favoritos</a>' +
      '<a href="account.html#recompensas" class="fs-menu-item">🏆 Recompensas</a>' +
      '<hr style="border:none;border-top:1px solid rgba(255,255,255,0.07);margin:4px 0">' +
      '<button class="fs-menu-item danger" id="fs-logout-btn">🚪 Cerrar sesión</button>' +
    '</div>';
  if (navRight && navRight.parentNode) {
    navRight.parentNode.insertBefore(navWrapper, navRight);
  } else {
    document.querySelector('nav').appendChild(navWrapper);
  }

  // ── Referencias a elementos ────────────────────────────────
  var overlay     = document.getElementById('fs-auth-overlay');
  var navBtn      = document.getElementById('fs-nav-btn');
  var navMenu     = document.getElementById('fs-nav-menu');
  var closeBtn    = document.getElementById('fs-auth-close');
  var loginErr    = document.getElementById('fs-login-err');
  var regErr      = document.getElementById('fs-reg-err');

  // ── Helpers ────────────────────────────────────────────────
  function openModal(panel) {
    overlay.classList.add('fs-open');
    showPanel(panel || 'login');
  }
  function closeModal() { overlay.classList.remove('fs-open'); }

  function showPanel(id) {
    ['login','register'].forEach(function (p) {
      document.getElementById('fs-panel-' + p).style.display = p === id ? '' : 'none';
    });
    document.querySelectorAll('.fs-tab').forEach(function (t) {
      t.classList.toggle('active', t.dataset.panel === id);
    });
    if (loginErr) loginErr.textContent = '';
    if (regErr)   regErr.textContent   = '';
  }

  function setLoading(btnId, loading) {
    var btn = document.getElementById(btnId);
    if (btn) btn.disabled = loading;
  }

  function errorMsg(elId, msg) {
    var el = document.getElementById(elId);
    if (el) el.textContent = msg;
  }

  function translateError(code) {
    var msgs = {
      'auth/user-not-found'      : 'No existe una cuenta con ese correo.',
      'auth/wrong-password'      : 'Contraseña incorrecta.',
      'auth/email-already-in-use': 'Ese correo ya está registrado.',
      'auth/weak-password'       : 'La contraseña debe tener al menos 6 caracteres.',
      'auth/invalid-email'       : 'El correo no es válido.',
      'auth/popup-closed-by-user': 'Cancelaste el inicio con Google.',
    };
    return msgs[code] || 'Ocurrió un error. Intenta de nuevo.';
  }

  // ── Crear / actualizar documento de usuario en Firestore ──
  function upsertUserDoc(user, extraData) {
    var ref = window.FS_DB.collection('usuarios').doc(user.uid);
    return ref.get().then(function (snap) {
      if (!snap.exists) {
        return ref.set(Object.assign({
          nombre          : user.displayName || (extraData && extraData.nombre) || 'Usuario',
          email           : user.email,
          fechaRegistro   : firebase.firestore.FieldValue.serverTimestamp(),
          totalCompras    : 0,
          puntosAcumulados: 0,
          nivel           : 'aficionado',
        }, extraData || {}));
      }
    });
  }

  // ── Google auth (compartida login/register) ────────────────
  function googleAuth() {
    var provider = new firebase.auth.GoogleAuthProvider();
    return window.FS_AUTH.signInWithPopup(provider);
  }

  // ── Eventos: tabs ──────────────────────────────────────────
  document.querySelectorAll('.fs-tab').forEach(function (tab) {
    tab.addEventListener('click', function () { showPanel(tab.dataset.panel); });
  });

  // ── Eventos: cerrar ────────────────────────────────────────
  closeBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', function (e) {
    if (e.target === overlay) closeModal();
  });

  // ── Google login ───────────────────────────────────────────
  document.getElementById('fs-google-login').addEventListener('click', function () {
    googleAuth().then(function (result) {
      return upsertUserDoc(result.user);
    }).then(closeModal)
      .catch(function (e) { errorMsg('fs-login-err', translateError(e.code)); });
  });

  document.getElementById('fs-google-register').addEventListener('click', function () {
    googleAuth().then(function (result) {
      return upsertUserDoc(result.user);
    }).then(closeModal)
      .catch(function (e) { errorMsg('fs-reg-err', translateError(e.code)); });
  });

  // ── Email login ────────────────────────────────────────────
  document.getElementById('fs-login-submit').addEventListener('click', function () {
    var email = document.getElementById('fs-login-email').value.trim();
    var pass  = document.getElementById('fs-login-pass').value;
    if (!email || !pass) { errorMsg('fs-login-err', 'Completa todos los campos.'); return; }
    setLoading('fs-login-submit', true);
    window.FS_AUTH.signInWithEmailAndPassword(email, pass)
      .then(closeModal)
      .catch(function (e) { errorMsg('fs-login-err', translateError(e.code)); })
      .finally(function () { setLoading('fs-login-submit', false); });
  });

  // ── Email register ─────────────────────────────────────────
  document.getElementById('fs-reg-submit').addEventListener('click', function () {
    var nombre = document.getElementById('fs-reg-name').value.trim();
    var email  = document.getElementById('fs-reg-email').value.trim();
    var pass   = document.getElementById('fs-reg-pass').value;
    if (!nombre || !email || !pass) { errorMsg('fs-reg-err', 'Completa todos los campos.'); return; }
    setLoading('fs-reg-submit', true);
    window.FS_AUTH.createUserWithEmailAndPassword(email, pass)
      .then(function (cred) {
        return cred.user.updateProfile({ displayName: nombre })
          .then(function () { return upsertUserDoc(cred.user, { nombre: nombre }); });
      })
      .then(closeModal)
      .catch(function (e) { errorMsg('fs-reg-err', translateError(e.code)); })
      .finally(function () { setLoading('fs-reg-submit', false); });
  });

  // ── Nav: toggle menú / abrir modal ────────────────────────
  navBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    var user = window.FS_AUTH.currentUser;
    if (user) {
      navMenu.classList.toggle('open');
    } else {
      openModal('login');
    }
  });

  document.addEventListener('click', function () { navMenu.classList.remove('open'); });

  // ── Logout ─────────────────────────────────────────────────
  document.getElementById('fs-logout-btn').addEventListener('click', function () {
    window.FS_AUTH.signOut().then(function () {
      navMenu.classList.remove('open');
      // Si estamos en account.html, redirigir al home
      if (window.location.pathname.indexOf('account') !== -1) {
        window.location.href = 'index.html';
      }
    });
  });

  // ── Observer: actualizar nav según sesión ─────────────────
  window.FS_AUTH.onAuthStateChanged(function (user) {
    if (user) {
      var display = user.displayName ? user.displayName.split(' ')[0] : 'Cuenta';
      navBtn.innerHTML = '👤 ' + display + ' <span id="fs-nav-badge"></span>';
      // Cargar nivel desde Firestore y mostrarlo
      window.FS_DB.collection('usuarios').doc(user.uid).get().then(function (snap) {
        if (snap.exists) {
          var data   = snap.data();
          var niveles = {
            aficionado  : { emoji: '⚽', label: 'Aficionado' },
            hincha      : { emoji: '🔥', label: 'Hincha'     },
            coleccionista:{ emoji: '🏆', label: 'Coleccionista'},
            leyenda     : { emoji: '👑', label: 'Leyenda'    },
          };
          var n = niveles[data.nivel] || niveles.aficionado;
          var badge = document.getElementById('fs-nav-badge');
          if (badge) badge.textContent = n.emoji + ' ' + n.label;
        }
      }).catch(function () {});
    } else {
      navBtn.innerHTML = '👤 Mi cuenta';
    }
  });

  // ── Exponer apertura del modal globalmente ─────────────────
  // Útil para botones externos: window.FSAuth.openModal('register')
  window.FSAuth = { openModal: openModal, closeModal: closeModal };

})();
